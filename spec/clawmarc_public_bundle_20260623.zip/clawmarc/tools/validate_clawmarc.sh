#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PY=${PYTHON:-/Users/kornai/miniconda3/bin/python3}

echo "== files"
test -f "$ROOT/draft/draft-kornai-clawmarc-00.md"
test -f "$ROOT/reference/clawmarc_catalog_card.h"
test -f "$ROOT/reference/libangel_card.py"
test -f "$ROOT/reference/libangel_catalog.py"
test -f "$ROOT/reference/libangel_mint.py"
test -f "$ROOT/reference/libangel_inspect.py"
test -f "$ROOT/cards/reference_dropofwater.cxcc"
test -f "$ROOT/cards/reference_dropofwater.cxcc.json"

echo "== header compile"
cat > /private/tmp/clawmarc_header_check.c <<EOF
#include "$ROOT/reference/clawmarc_catalog_card.h"
int main(void) {
    return sizeof(ClawXivCatalogCardV1) == 4096 ? 0 : 1;
}
EOF
cc -std=c11 -Wall -Wextra -Werror -o /private/tmp/clawmarc_header_check /private/tmp/clawmarc_header_check.c
/private/tmp/clawmarc_header_check

echo "== python compile"
env PYTHONPYCACHEPREFIX=/private/tmp/clawmarc-pycache "$PY" -m py_compile \
  "$ROOT/reference/libangel_card.py" \
  "$ROOT/reference/libangel_catalog.py" \
  "$ROOT/reference/libangel_mint.py" \
  "$ROOT/reference/libangel_inspect.py"

echo "== reference card"
PYTHONPATH="$ROOT/reference" "$PY" "$ROOT/reference/libangel_inspect.py" "$ROOT/cards/reference_dropofwater.cxcc" >/private/tmp/clawmarc-card.inspect
grep -q '^object_sha256: 325a3123ad5f4bc43a3a26358163764d20546e454a5759239b4c3f412f488c51$' /private/tmp/clawmarc-card.inspect
grep -q '^schema_sha256: f600c8e20fe31f7bddc0a8bf9e36f0917723a1c1b161c3d5693eac09c6672480$' /private/tmp/clawmarc-card.inspect
PYTHONPATH="$ROOT/reference" "$PY" "$ROOT/reference/libangel_inspect.py" --json "$ROOT/cards/reference_dropofwater.cxcc" >/private/tmp/clawmarc-card.inspect.json
grep -q '"text_sha256": "c209c1417e8f5e58f1822600de46d63ac26544eb9f369f208d52e5e7aa1adbaa"' /private/tmp/clawmarc-card.inspect.json

echo "== public draft scrub"
if grep -R '~/Proj\\|Blackboard\\|r1/r2/r3\\|Standards track' "$ROOT/draft"; then
  echo "public draft contains private/provenance language" >&2
  exit 1
fi

echo "OK"
